# from errno import ESTALE

# from django.contrib import messages
# from django.contrib.auth.decorators import login_required
# from django.core.paginator import Paginator
# from django.http import HttpResponse, HttpResponseNotAllowed
# from django.shortcuts import get_object_or_404, redirect, render
# from django.utils import timezone

# from pybo.forms import AnswerForm, QuestionForm
# from pybo.models import Answer, Question


# def index(request):
#     page=request.GET.get('page','1')
#     # 페이지값없을경우 1
    
#     question_list=Question.objects.order_by('-create_date') 
#     paginator=Paginator(question_list,10)
#     page_obj=paginator.get_page(page)
#     # context값만 바꿔야 form에서 다 받기때문
#     context={'question_list':page_obj}
#     page_obj.start_index
#     # ,이게 셋 :딕셔너리
#     # request는 http요청객체라고보면됨
#     return render(request,'pybo/question_list.html',context)
# # render=파이썬데이터를 템플릿에 적용하여 html로 변환하는 함수
# # Create your views here.

# # 패턴은  브라우저 localhost->urls.py->views.py-> localhost
# def detail(request,question_id):
    
#     # url매핑시 저장된 quesiton_id를 가져옴 int
#     # 매개변수꼭받아서 id에 넣어야함
    
#     question=get_object_or_404(Question,pk=question_id)
#     # 위에꺼 getid한거나 마찬가지다
#     # question=Question.objects.get(id=question_id)
#     context={'question':question}
    
#     return render(request,'pybo/question_detail.html',context)


# @login_required(login_url='common:login')
# def question_create(request):
#     if request.method=="POST":
#         form=QuestionForm(request.POST)
#         # 이렇게할경우 request.Post의값이 QuestionForm에 자동저장됨
#         if form.is_valid():
#             question=form.save(commit=False)
#             question.author=request.user

#             question.create_date=timezone.now()
#             question.save()
#             return redirect('pybo:index')
#             # commit=False는 임시저장
#             # 그냥 form.save()할경우 속성이 부족해서 에러가나기때문에
   
    
#     else:
#         form=QuestionForm()
#     context={'form':form}
#     # 비었을때는 get 아니면 request.POST를 써줌
#     # 컨텍스트를 원래는 다써야하는데 form으로 집합처리해줌
#     return render(request,'pybo/question_form.html',context)

# @login_required(login_url='common:login')
# def question_modify(request,question_id):
#     question=get_object_or_404(Question,pk=question_id)
#     if request.user !=question.author:
#         messages.error(request,'수정권한없음')
#         return redirect('pybo:detail',question_id=question.id)
#     if request.method == "POST":
#         form=QuestionForm(request.POST,instance=question)
#         if form.is_valid():
#             question=form.save(commit=False)
#             question.modify_date=timezone.now()
#             question.save()
#             return redirect('pybo:detail',question_id=question.id)
#     else:
#         form=QuestionForm(instance=question)
#         # 폼의 속성값이 instace의 값으로 채워진다 채워진채로보여지게하기위해서임
#     context={form:form}
#     return render(request,'pybo/question_form.html',context)
#         # instance기준으로 생성하지만,request.post로 덮어써라
#     # request.POST=POST된 폼객체르 가져오는거라서 GET과달리 초기화가이미
#     # 된상태이므로 따로 초기화안해줌
#     # POST로받았기때문에 따로 전소알필욘없고 그냥 REDIRECT로 ID전달가능
#     # 하지만,GET일경우 새롭게 렌더를 해줘서 FORM을 업데이터해줘야함
# @login_required(login_url='common:login')
# def question_delete(request, question_id):
#     question = get_object_or_404(Question, pk=question_id)
#     if request.user != question.author:
#         messages.error(request, '삭제권한이 없습니다')
#         return redirect('pybo:detail', question_id=question.id)
#     question.delete()
#     return redirect('pybo:index')


# @login_required(login_url='common:login')
# def answer_create(request,question_id):
#     # 없어서 pk kargs이므로 키워드넣어서 int값으로 치환해줘야함
#     question=get_object_or_404(Question,pk=question_id)
    
#     if request.method=="POST":
#         form=AnswerForm(request.POST)
#         if form.is_valid():
#             answer=form.save(commit=False)
#             answer.author=request.user
            
#             answer.create_date=timezone.now()
#             answer.question=question
#             answer.save()
#             return redirect("pybo:detail",question.id)
#     else:
#         form=AnswerForm()
#         # 에러를 form=AnswerForm()으로
#         # 답변은 post만 get으로 이미 가져왔기때문에 get은더쓸필요없음
    
#     context={'question':question,'form':form}
#     # question.answer_set.create(content=request.POST.get('content'),create_date=timezone.now())
#     return render(request,'pybo/question_detail.html',context)
# # html에서는 url로 가져오고, view에서는 redirect로 리턴하는방식이며, 둘다 딕셔너리씀
#     # {,취급하기}{}set dictioanry, list []익숙 tuble() 안익숙
#     # set형태임 수정불가능한 형태?라고봐도될듯
# @login_required(login_url='common:login')
# def answer_modify(request,answer_id):
#     answer=get_object_or_404(Answer,pk=answer_id)
#     if request.user!=answer.author:
#         messages.error(request,'수정권한 없음')
#         return redirect('pybo:detail',question_id=answer.question.id)
#     # 가져왔다고 깔아놨기때문에 method 자동완성가능
#     if request.method == "POST":
#         form=AnswerForm(request.POST,instance=answer)
#         if form.is_valid():
#             answer=form.save(commit=False)
#             answer.modify_date=timezone.now()
#             answer.save()
#             # 옌아직 속성도 완성이안된빈거라서 자동완성안됨
#             return redirect('pybo:detail',question_id=answer.question.id)
#             # 이건그냥 일시적으로 이동시키는것뿐 전달까지는 아닌 메소드
#     else:
#         form=AnswerForm(instance=answer)
#     context={'answer':answer,'form':form}
#         # 렌더로 html에 값을 전달
#         # 이게 리턴형
#     return render(request,'pybo/answer_form.html',context)

# @login_required(login_url='common:login')
# def answer_delete(request,answer_id):
#     # noninterable for range가안되면 뜨는오류인데
#     # 이때는 못찾아서 interable뜸 pk안붙일시
#     answer=get_object_or_404(Answer,pk=answer_id)
#     if request.user!=answer.author:
#         messages(request,'삭제권한 없음')
#     else:
#         answer.delete()
#     return redirect('pybo:detail',question_id=answer.question.id)


