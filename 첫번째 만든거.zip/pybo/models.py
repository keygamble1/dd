from django.contrib.auth.models import User
from django.db import models


# migrations는 model entity를 변경할시 무조건 업데이트해야함
# 생성하는것도있찌만 업뎃하는것도맞음
class Question(models.Model):
    modify_date=models.DateTimeField(null=True,blank=True)
    author=models.ForeignKey(User,on_delete=models.CASCADE,related_name='author_question')
    subject=models.CharField(max_length=200)
    content=models.TextField()
    create_date=models.DateTimeField()
    voter=models.ManyToManyField(User,related_name='voter_question')
    # 기준점이없으면 오류  realated_name이라고써줘야함

    # 쉘에서 id대신 제목
    def  __str__(self):
        return self.subject
    
    # request=요청 require필수
class Answer(models.Model):
    modify_date=models.DateTimeField(null=True,blank=True)
    author=models.ForeignKey(User,on_delete=models.CASCADE,related_name='author_answer')
    # 종속됨 대신 다대 일로됨
    question=models.ForeignKey(Question,on_delete=models.CASCADE)
    content=models.TextField()
    create_date=models.DateTimeField()
    voter=models.ManyToManyField(User,related_name='voter_answer')
    # Q에서는 다를 조회하기위해서 set으로
    # Q는 한개만조회하기때문에 그냥 qestion단일로
# Create your models here.
