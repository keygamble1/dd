from django.test import TestCase
from django.utils import timezone

from pybo.models import Question


# Create your tests here.
class MymodelTest(TestCase):
    for i in range(300):
        q=Question(subject='테스트데이터[%3d]' % i,content='내용무',create_date=timezone.now())
        q.save()