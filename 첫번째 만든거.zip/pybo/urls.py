


from django.urls import path

from . import views
from .views import answer_view, base_view, question_view

# 다른앱사용할수있기때문에 namespace정해줌

app_name='pybo'
urlpatterns = [
    
    # html 쓰고 html 안에 % url 쓰고 url에서 views 정의하고 views에서 쓰고
    # int형이며  questionid는 views에서
    path('',base_view.index,name='index'),
    path('<int:question_id>/',base_view.detail,name='detail'),
    # 무조건 끝에 /를 해줘야함 안그러면 타입이달라짐
    # question_id는 views에서 정의해서 받아올거
    # url과 view와 html연결점임
    
    path('question/create/',question_view.question_create,name='question_create'),
    path('question/modify/<int:question_id>/',question_view.question_modify,name='question_modify'),
    path('question/delete/<int:question_id>/',question_view.question_delete,name='question_delete'),
    path('question/vote/<int:question_id>/',question_view.question_vote,name='question_vote'),
    
    path('answer/create/<int:question_id>/',answer_view.answer_create,name='answer_create'),
    path('answer/modify/<int:answer_id>/',answer_view.answer_modify,name='answer_modify'),
    path('answer/delete/<int:answer_id>/', answer_view.answer_delete, name='answer_delete'),
    path('answer/vote/<int:answer_id>',answer_view.answer_vote,name='answer_vote'),
    # question_id를 views에 전달한다
    # urls에서 name으로 html로 전달, urls 왼쪽에있는 view로 전달
    
]
