from errno import ESTALE

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Q
from django.http import HttpResponse, HttpResponseNotAllowed
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from pybo.forms import AnswerForm, QuestionForm
from pybo.models import Answer, Question


def index(request):
    page=request.GET.get('page','1')
    kw=request.GET.get('kw','')
    
    # 페이지값없을경우 1
    
    question_list=Question.objects.order_by('-create_date') 
    
    if kw:
        question_list=question_list.filter(
            Q(subject__icontains=kw) |
            Q(content__icontains=kw) |
            Q(answer__content__icontains=kw) |
            Q(author__username__icontains=kw) |
            Q(answer__author__username__icontains=kw) 
            
        ).distinct()
    paginator=Paginator(question_list,10)
    page_obj=paginator.get_page(page)
    # context값만 바꿔야 form에서 다 받기때문
    context={'question_list':page_obj,'page':page,'kw':kw}
    page_obj.start_index
    # ,이게 셋 :딕셔너리
    # request는 http요청객체라고보면됨
    return render(request,'pybo/question_list.html',context)
# render=파이썬데이터를 템플릿에 적용하여 html로 변환하는 함수
# Create your views here.

def detail(request,question_id):
    
    # url매핑시 저장된 quesiton_id를 가져옴 int
    # 매개변수꼭받아서 id에 넣어야함
    
    question=get_object_or_404(Question,pk=question_id)
    # 위에꺼 getid한거나 마찬가지다
    # question=Question.objects.get(id=question_id)
    context={'question':question}
    
    return render(request,'pybo/question_detail.html',context)
# 코드는 수정삭제가 비번하므로 삭제된부분되살리고싶을경우 GIT
# 동일한소스코드를 여러명이 수정하는경우도생기기때문에 누가수정했는지도
# 다관리가능
# git init 하고 git status는 상태
# git add해야하지만 사용자별로 나눌때 .idea나 db.sqlite3는 시스템,사용자별이므로 넣으면 앋냄
# 개인정보기때문그때는 .gitignore로 관리안할대상지정해야함
# git은 저장소에 바로 올리지않고, staging을거침, 변경사항에 저장하기전
# 직전단계의 개념 git add <파일명>하면 지정파일이 스테이지영역에 추가되며
# 그후에 git commit며령해야 저장소에저장함
# git->stage->저장소인데
# gitadd->stage로
# git commit->저장소로
# ㅇㅇ<>
# ddd