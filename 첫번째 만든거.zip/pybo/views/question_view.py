from errno import ESTALE

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.http import HttpResponse, HttpResponseNotAllowed
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from pybo.forms import AnswerForm, QuestionForm
from pybo.models import Answer, Question


@login_required(login_url='common:login')
def question_create(request):
    if request.method=="POST":
        form=QuestionForm(request.POST)
        # 이렇게할경우 request.Post의값이 QuestionForm에 자동저장됨
        if form.is_valid():
            question=form.save(commit=False)
            question.author=request.user

            question.create_date=timezone.now()
            question.save()
            return redirect('pybo:index')
            # commit=False는 임시저장
            # 그냥 form.save()할경우 속성이 부족해서 에러가나기때문에
   
    
    else:
        form=QuestionForm()
    context={'form':form}
    # 비었을때는 get 아니면 request.POST를 써줌
    # 컨텍스트를 원래는 다써야하는데 form으로 집합처리해줌
    return render(request,'pybo/question_form.html',context)

@login_required(login_url='common:login')
def question_modify(request,question_id):
    question=get_object_or_404(Question,pk=question_id)
    if request.user !=question.author:
        messages.error(request,'수정권한없음')
        return redirect('pybo:detail',question_id=question.id)
    if request.method == "POST":
        form=QuestionForm(request.POST,instance=question)
        if form.is_valid():
            question=form.save(commit=False)
            question.modify_date=timezone.now()
            question.save()
            return redirect('pybo:detail',question_id=question.id)
    else:
        form=QuestionForm(instance=question)
        # 폼의 속성값이 instace의 값으로 채워진다 채워진채로보여지게하기위해서임
    context={form:form}
    return render(request,'pybo/question_form.html',context)
        # instance기준으로 생성하지만,request.post로 덮어써라
    # request.POST=POST된 폼객체르 가져오는거라서 GET과달리 초기화가이미
    # 된상태이므로 따로 초기화안해줌
    # POST로받았기때문에 따로 전소알필욘없고 그냥 REDIRECT로 ID전달가능
    # 하지만,GET일경우 새롭게 렌더를 해줘서 FORM을 업데이터해줘야함
@login_required(login_url='common:login')
def question_delete(request, question_id):
    question = get_object_or_404(Question, pk=question_id)
    if request.user != question.author:
        messages.error(request, '삭제권한이 없습니다')
        return redirect('pybo:detail', question_id=question.id)
    question.delete()
    return redirect('pybo:index')


@login_required(login_url='common.login')
def question_vote(request,question_id):
    question=get_object_or_404(Question,pk=question_id)
    if request.user==question.author:
        messages.error(request,'본인추천x')
    else:
        question.voter.add(request.user)
    return redirect('pybo:detail',question.id)