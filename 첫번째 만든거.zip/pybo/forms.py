
from django import forms

from pybo.models import Answer, Question


class QuestionForm(forms.ModelForm):
    
    class Meta:
        model= Question
        fields =['subject','content']
        # 일반폼(forms.Form)과 모델폼(forms.ModelForm) 이있는데
        # 모델폼은 모델과 연결된폼으로 저장시 연결된 모델의 데이터를 저장가능한폼
        # 모델폼은 이너크래스인 Meta클래스가 반드시필요
        # 모델클ㅐ스에는 사용할 모델 및 속성을 무조건 적어야함
        # widgets={
        #     'subject':forms.TextInput(attrs={'class':'form-control'}),
        #     'content':forms.Textarea(attrs={'class':'form-control','rows':10})
        # }
        labels={
            'subject':'제목',
            'content':'내용',
        }

class AnswerForm(forms.ModelForm):
    class Meta:
        model = Answer
        fields = ['content']
        labels={
            'content':'답변내용'
        }
    