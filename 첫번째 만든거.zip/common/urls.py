from django.contrib.auth import views as auth_views
from django.urls import path

from common import views
from common.views import logout_view, signup

app_name='common'

urlpatterns = [
    # htmlcommon:loging했으니, url controller 정의해줘야함
    path('login/',auth_views.LoginView.as_view(template_name='common/login.html'),name='login'),
    # loginview는 registarion/login.html을 찾음 하지만 commont에 생성하느게좋음
    path('logout/',views.logout_view,name='logout'),
    path('signup/',views.signup,name='signup'),
]
