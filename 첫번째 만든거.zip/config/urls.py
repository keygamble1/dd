"""
URL configuration for config project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import include, path

from pybo import views
from pybo.views import base_view

urlpatterns = [
    # 404나오면 url에서 requestion되는게없다는뜻
    path('admin/', admin.site.urls),
    path('pybo/',include('pybo.urls')),
    path('common/',include('common.urls')),
    path('',base_view.index,name='index'),
    # 대응되는 매핑규칙을 config에입력
    # comfing common/ + commond의 url에서 login/일시
    # common/login이됨
    # pybo/ + phbourls(/create/ansewr/) 이런식으로 수행됨
    # views.index대신 include해서 pybo/를 기본으로 requestmapping하라는뜻
]
